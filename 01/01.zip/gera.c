#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

int main(int argi, char **argc) {
    short n; // comprimento das strings e idade
    int i;
    char nome[21];
    char end[21];
    char com[100];
    srand( clock() );
    if(argi < 3) {
            printf("Uso: %s <tipo> <numero>\r\n\r\n"
                   "Cria uma base do tipo <tipo> com <numero> registros gerados aleatoriamente.\r\n", argc[0]);
    } else {
           sprintf(com, "DB %s db.dat db.idx", argc[1]);
           system(com);
           for(sscanf(argc[2], "%i", &i);i>0;i--) {
                     n = (int)((float)rand()/(float)RAND_MAX*20);                     
                     for(nome[n] = '\0'; n >= 0; n--) nome[n] = 97 + (int)((float)rand()/(float)RAND_MAX*25);
                     n = (int)((float)rand()/(float)RAND_MAX*20);
                     for(end[n] = '\0'; n >= 0; n--) end[n] = 97 + (int)((float)rand()/(float)RAND_MAX*25);
                     n = (int)((float)rand()/(float)RAND_MAX*100);
                     sprintf(com, "DB i db.dat db.idx %i %i %s %s", i, n, nome, end);
                     system(com);                                          
           }
      printf("-- Terminado.\r\n");
      }    
    return 0;
}

