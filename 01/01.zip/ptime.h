#ifndef __PTIME_H
#define __PTIME_H

float ptime(void);

#endif
